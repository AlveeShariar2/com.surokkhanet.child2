package com.surokkhanet.child

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object ScreenStreamer {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isStreaming = false
    private val executor = Executors.newSingleThreadExecutor()
    private var captureInterval: Long = 5000 // ডিফল্ট ৫ সেকেন্ড

    fun setCaptureInterval(seconds: Int) {
        captureInterval = (seconds * 1000).toLong()
    }

    fun startStreaming(context: Context, resultCode: Int, data: Intent) {
        if (isStreaming) {
            Log.w("ScreenStreamer", "স্ট্রিমিং ইতিমধ্যেই চলছে")
            return
        }

        try {
            val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            
            val metrics = context.resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val dpi = metrics.densityDpi
            
            // RGBA_8888 ফরম্যাটে ইমেজ রিডার তৈরি
            imageReader = ImageReader.newInstance(width, height, ImageFormat.RGBA_8888, 2)
            
            // ভার্চুয়াল ডিসপ্লে তৈরি
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "ChildSafetyStream",
                width,
                height,
                dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                null
            )
            
            isStreaming = true
            Log.i("ScreenStreamer", "স্ক্রিন স্ট্রিমিং শুরু হয়েছে: ${width}x${height}")
            
            // প্রথম ক্যাপচার শিডিউল করুন
            handler.postDelayed(captureRunnable, captureInterval)
        } catch (e: Exception) {
            Log.e("ScreenStreamer", "স্ট্রিমিং শুরু করতে ব্যর্থ: ${e.message}")
            stopStreaming()
        }
    }

    fun stopStreaming() {
        if (!isStreaming) return
        
        try {
            handler.removeCallbacks(captureRunnable)
            virtualDisplay?.release()
            mediaProjection?.stop()
            imageReader?.close()
            
            virtualDisplay = null
            mediaProjection = null
            imageReader = null
            isStreaming = false
            
            Log.i("ScreenStreamer", "স্ক্রিন স্ট্রিমিং বন্ধ হয়েছে")
        } catch (e: Exception) {
            Log.e("ScreenStreamer", "স্ট্রিমিং বন্ধ করতে ব্যর্থ: ${e.message}")
        }
    }

    private val captureRunnable = object : Runnable {
        override fun run() {
            if (isStreaming) {
                captureScreen()
                // পরবর্তী ক্যাপচার শিডিউল করুন
                handler.postDelayed(this, captureInterval)
            }
        }
    }

    private fun captureScreen() {
        val image = imageReader?.acquireLatestImage()
        if (image != null) {
            executor.execute {
                try {
                    processAndUploadImage(image)
                } catch (e: Exception) {
                    Log.e("ScreenStreamer", "ইমেজ প্রসেস করতে ব্যর্থ: ${e.message}")
                } finally {
                    image.close()
                }
            }
        }
    }

    private fun processAndUploadImage(image: Image) {
        // ইমেজ ডেটা প্রসেস করুন
        val width = image.width
        val height = image.height
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        // বিটম্যাপ তৈরি করুন
        val bitmap = Bitmap.createBitmap(
            width + rowPadding / pixelStride, 
            height, 
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        // JPEG এ কনভার্ট করুন
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        val jpegBytes = outputStream.toByteArray()
        
        // Firebase এ আপলোড করুন
        uploadToFirebase(jpegBytes)
        
        Log.d("ScreenStreamer", "স্ক্রিনশট ক্যাপচার করা হয়েছে: ${width}x${height}")
    }

    private fun uploadToFirebase(imageBytes: ByteArray) {
        try {
            val storage = FirebaseStorage.getInstance()
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val fileName = "screenshot_$timestamp.jpg"
            val storageRef = storage.reference.child("screenshots/$fileName")
            
            storageRef.putBytes(imageBytes)
                .addOnSuccessListener {
                    Log.d("Firebase", "স্ক্রিনশট আপলোড হয়েছে: $fileName")
                }
                .addOnFailureListener { e ->
                    Log.e("Firebase", "স্ক্রিনশট আপলোড ব্যর্থ: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("Firebase", "ফায়ারবেজে সংযোগ করতে ব্যর্থ: ${e.message}")
        }
    }
}