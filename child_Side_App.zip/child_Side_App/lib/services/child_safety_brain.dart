import 'package:tflite_flutter/tflite_flutter.dart';

class ChildSafetyBrain {
  static Future<double> checkRisk() async {
    try {
      // ১. মডেল লোড করা
      final interpreter = await Interpreter.fromAsset('assets/behavior_model.tflite');
      
      // ২. শিশুর ফোন ব্যবহারের ডেটা (এখানে উদাহরণ ডেটা)
      final childData = [3.0, 10.0, 120.0]; // [ঘণ্টা, অ্যাপ সংখ্যা, স্ক্রিন টাইম]
      
      // ৩. ইনপুট প্রস্তুত করা
      final input = [childData];
      final output = List<double>.filled(1, 0).reshape([1, 1]);
      
      // ৪. মডেল চালানো
      interpreter.run(input, output);
      
      // ৫. ফলাফল রিটার্ন করা
      final riskLevel = output[0][0];
      return riskLevel;
    } catch (e) {
      print('Error: $e');
      return 0.0;
    }
  }
}