import 'package:child_app/services/supabase_service.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/utils/native_channel.dart';
import 'package:child_app/services/screen_stream_service.dart';
import 'package:child_app/utils/secure_prefs.dart';

class CommandHandler {
  static RealtimeSubscription? _commandSubscription;
  static late String deviceId;

  static Future<void> initialize() async {
    deviceId = await Constants.getDeviceId();
    
    // Subscribe to realtime commands
    _commandSubscription = SupabaseService.listenToCommands(deviceId, (command) {
      _processCommand(command['id'], command);
    });
  }

  static void dispose() {
    _commandSubscription?.unsubscribe();
  }

  static Future<void> _processCommand(String commandId, Map<String, dynamic> command) async {
    try {
      // Update status to processing
      await SupabaseService.updateCommandStatus(commandId, 'processing');
      
      switch (command['type']) {
        case 'lock_device':
          await NativeChannel.lockDevice();
          await SupabaseService.updateCommandStatus(commandId, 'completed');
          break;
          
        case 'take_screenshot':
          final imagePath = await NativeChannel.captureScreen();
          if (imagePath != null) {
            await SupabaseService.updateCommandStatus(
              commandId, 
              'completed', 
              resultData: {'imagePath': imagePath}
            );
          } else {
            await SupabaseService.updateCommandStatus(commandId, 'failed');
          }
          break;
          
        case 'start_stream':
          await ScreenStreamService.startStreaming();
          await SupabaseService.updateCommandStatus(commandId, 'completed');
          break;
          
        case 'stop_stream':
          await ScreenStreamService.stopStreaming();
          await SupabaseService.updateCommandStatus(commandId, 'completed');
          break;
          
        case 'get_location':
          final location = await NativeChannel.getLocation();
          await SupabaseService.updateCommandStatus(
            commandId, 
            'completed', 
            resultData: {'location': location}
          );
          break;
          
        case 'get_call_logs':
          final callLogs = await NativeChannel.getCallLogs();
          await SupabaseService.updateCommandStatus(
            commandId, 
            'completed', 
            resultData: {'callLogs': callLogs}
          );
          break;
          
        case 'get_sms':
          final sms = await NativeChannel.getSms();
          await SupabaseService.updateCommandStatus(
            commandId, 
            'completed', 
            resultData: {'sms': sms}
          );
          break;
          
        case 'uninstall_app':
          final parentCode = command['code']?.toString();
          if (parentCode != null) {
            final isValid = await SecurePrefs.verifyParentCode(parentCode);
            if (isValid) {
              final removed = await NativeChannel.removeDeviceAdmin();
              if (removed) {
                await NativeChannel.uninstallSelf();
                await SupabaseService.updateCommandStatus(commandId, 'completed');
              } else {
                await SupabaseService.updateCommandStatus(
                  commandId, 
                  'failed', 
                  error: 'remove_admin_failed'
                );
              }
            } else {
              await SupabaseService.updateCommandStatus(commandId, 'denied');
            }
          } else {
            await SupabaseService.updateCommandStatus(
              commandId, 
              'failed', 
              error: 'no_code_provided'
            );
          }
          break;
          
        default:
          await SupabaseService.updateCommandStatus(
            commandId, 
            'failed', 
            error: 'unknown_command_type'
          );
      }
    } catch (e) {
      await SupabaseService.updateCommandStatus(
        commandId, 
        'failed', 
        error: e.toString()
      );
    }
  }
}