import 'package:geolocator/geolocator.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/services/supabase_service.dart';

class LocationService {
  static StreamSubscription<Position>? _positionStream;

  static void start() {
    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100, // meters
      )
    ).listen((Position position) async {
      final deviceId = await Constants.getDeviceId();
      await SupabaseService.saveLocation(
        deviceId,
        position.latitude,
        position.longitude,
        position.accuracy,
      );
    });
  }

  static void stop() {
    _positionStream?.cancel();
    _positionStream = null;
  }

  static Future<Position?> getCurrentLocation() async {
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
    } catch (e) {
      return null;
    }
  }
}