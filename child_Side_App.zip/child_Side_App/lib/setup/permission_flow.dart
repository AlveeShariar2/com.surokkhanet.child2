import 'package:flutter/material.dart';
import 'package:child_app/utils/native_channel.dart';

class PermissionFlow extends StatefulWidget {
  const PermissionFlow({super.key});

  @override
  State<PermissionFlow> createState() => _PermissionFlowState();
}

class _PermissionFlowState extends State<PermissionFlow> {
  int _currentStep = 0;

  final List<Map<String, dynamic>> steps = [
    {
      'title': 'Device Admin',
      'description': 'Enable device administration for security features',
      'action': NativeChannel.activateDeviceAdmin,
    },
    {
      'title': 'Accessibility',
      'description': 'Enable accessibility services for monitoring',
      'action': NativeChannel.openAccessibilitySettings,
    },
    {
      'title': 'Background Services',
      'description': 'Enable background services for continuous protection',
      'action': NativeChannel.startStealthService,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Setup Permissions')),
      body: Stepper(
        currentStep: _currentStep,
        onStepContinue: () async {
          await steps[_currentStep]['action']();
          if (_currentStep < steps.length - 1) {
            setState(() {
              _currentStep++;
            });
          } else {
            // Complete setup
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const LinkScreen()),
            );
          }
        },
        steps: steps.map((step) {
          return Step(
            title: Text(step['title']),
            content: Text(step['description']),
          );
        }).toList(),
      ),
    );
  }
}