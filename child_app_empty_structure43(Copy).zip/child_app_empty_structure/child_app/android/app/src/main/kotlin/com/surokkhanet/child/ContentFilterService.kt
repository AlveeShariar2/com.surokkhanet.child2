package com.surokkhanet.child

import android.service.notification.NotificationListenerService
import android.util.Log

class ContentFilterService : NotificationListenerService() {
    private val blockedDomains = listOf(
        "porn", "xxx", "adult", "gambling", 
        "betting", "violent", "hacking"
    )

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn?.notification?.extras?.let { extras ->
            val title = extras.getString("android.title")
            val text = extras.getString("android.text")

            if (containsBlockedContent(title) || containsBlockedContent(text)) {
                cancelNotification(sbn.key)
                Log.d("ContentFilter", "Blocked notification: $title")
            }
        }
    }

    private fun containsBlockedContent(content: String?): Boolean {
        return blockedDomains.any { domain -> 
            content?.contains(domain, ignoreCase = true) == true 
        }
    }
}