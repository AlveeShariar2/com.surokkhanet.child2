package com.surokkhanet.child

import android.content.Context
import com.google.firebase.storage.FirebaseStorage
import java.io.File

object FileTransferService {
    fun uploadFile(context: Context, filePath: String) {
        val file = File(filePath)
        if (!file.exists()) return

        val storage = FirebaseStorage.getInstance()
        val storageRef = storage.reference
        val fileRef = storageRef.child("files/${file.name}")

        fileRef.putFile(android.net.Uri.fromFile(file))
            .addOnSuccessListener { /* Handle success */ }
            .addOnFailureListener { /* Handle failure */ }
    }
}