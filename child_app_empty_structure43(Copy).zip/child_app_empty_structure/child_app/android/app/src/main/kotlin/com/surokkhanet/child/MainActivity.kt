class MainActivity : FlutterActivity() {
  private val CHANNEL = "child_app/native_channel"
  private var mediaProjection: MediaProjection? = null
  private var virtualDisplay: VirtualDisplay? = null
  private var imageReader: ImageReader? = null
  private var captureInterval: Int = 5 // seconds

  override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
      when (call.method) {
        "startScreenStream" -> startScreenStream(result)
        "stopScreenStream" -> stopScreenStream(result)
        "setCaptureInterval" -> setCaptureInterval(call, result)
        "captureScreenFrame" -> captureFrame(result)
        "isStreamActive" -> result.success(mediaProjection != null)
        else -> result.notImplemented()
      }
    }
  }

  private fun startScreenStream(result: Result) {
    val mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
    startActivityForResult(captureIntent, SCREEN_CAPTURE_REQUEST)
    result.success(null)
  }

  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    if (requestCode == SCREEN_CAPTURE_REQUEST) {
      if (resultCode == RESULT_OK && data != null) {
        setupScreenCapture(resultCode, data)
      }
    }
  }

  private fun setupScreenCapture(resultCode: Int, data: Intent) {
    val mediaProjectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)
    
    val metrics = resources.displayMetrics
    val density = metrics.densityDpi
    val width = metrics.widthPixels
    val height = metrics.heightPixels
    
    imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
    
    virtualDisplay = mediaProjection?.createVirtualDisplay(
      "ScreenCapture",
      width,
      height,
      density,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
      imageReader?.surface,
      null,
      null
    )
  }

  private fun captureFrame(result: Result) {
    try {
      val image = imageReader?.acquireLatestImage()
      if (image != null) {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        image.close()
        result.success(bytes)
      } else {
        result.success(null)
      }
    } catch (e: Exception) {
      result.error("CAPTURE_ERROR", "Frame capture failed", e.toString())
    }
  }

  private fun setCaptureInterval(call: MethodCall, result: Result) {
    captureInterval = call.argument<Int>("seconds") ?: 5
    result.success(null)
  }

  private fun stopScreenStream(result: Result) {
    virtualDisplay?.release()
    mediaProjection?.stop()
    virtualDisplay = null
    mediaProjection = null
    result.success(null)
  }

  companion object {
    private const val SCREEN_CAPTURE_REQUEST = 1001
  }
}