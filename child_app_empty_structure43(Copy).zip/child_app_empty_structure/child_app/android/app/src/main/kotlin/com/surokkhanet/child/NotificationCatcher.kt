package com.surokkhanet.child

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class NotificationCatcher : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            if (it.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                val packageName = it.packageName?.toString() ?: "unknown_package"
                val message = it.text?.joinToString() ?: ""
                
                // ফায়ারবেজে সেন্ড করুন
                sendToFirestore(packageName, message)
            }
        }
    }

    private fun sendToFirestore(packageName: String, message: String) {
        try {
            val data = hashMapOf(
                "package" to packageName,
                "message" to message,
                "timestamp" to System.currentTimeMillis()
            )

            Firebase.firestore.collection("notifications")
                .add(data)
                .addOnSuccessListener {
                    Log.d("Firebase", "নোটিফিকেশন সেভ হয়েছে: $packageName")
                }
                .addOnFailureListener { e ->
                    Log.e("Firebase", "নোটিফিকেশন সেভ করতে ব্যর্থ: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("Firebase", "ফায়ারবেজে সংযোগ করতে ব্যর্থ: ${e.message}")
        }
    }

    override fun onInterrupt() {
        Log.d("NotificationCatcher", "সার্ভিস বাধাপ্রাপ্ত হয়েছে")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i("NotificationCatcher", "নোটিফিকেশন সার্ভিস সংযুক্ত হয়েছে")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.w("NotificationCatcher", "নোটিফিকেশন সার্ভিস বন্ধ হয়েছে")
    }
}