override fun onReceive(context: Context, intent: Intent) {
  if (intent.data?.host == "241051") {
    // স্টিলথ মোড টোগল করুন
  }
}