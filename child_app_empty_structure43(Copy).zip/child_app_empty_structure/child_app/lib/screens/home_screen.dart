// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:child_app/services/child_safety_brain.dart';
import 'package:child_app/setup/welcome_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double _riskLevel = 0.0;
  bool _showWelcome = true;

  void _checkSafety() async {
    final risk = await ChildSafetyBrain.checkRisk();
    setState(() {
      _riskLevel = risk;
      _showWelcome = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return _showWelcome 
      ? const WelcomeScreen()
      : Scaffold(
          appBar: AppBar(
            title: const Text('শিশু সুরক্ষা'),
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => setState(() => _showWelcome = true),
            ),
          ),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'ঝুঁকি মাত্রা: ${(_riskLevel * 100).toStringAsFixed(1)}%',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: _checkSafety,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    ),
                    child: const Text(
                      'নিরাপত্তা চেক করুন',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'নিয়মিত চেক করে আপনার শিশুর নিরাপত্তা নিশ্চিত করুন',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ),
        );
  }
}