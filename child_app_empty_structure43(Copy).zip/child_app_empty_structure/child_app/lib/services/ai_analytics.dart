import 'package:tflite_flutter/tflite_flutter.dart';

class AIBehaviorAnalyzer {
  late Interpreter _interpreter;

  Future<void> initialize() async {
    _interpreter = await Interpreter.fromAsset('behavior_model.tflite');
  }

  Map<String, dynamic> analyzeActivity(Map<String, dynamic> activityData) {
    final input = [activityData.values.toList()];
    final output = List.filled(1, 0).reshape([1, 1]);
    
    _interpreter.run(input, output);
    
    final prediction = output[0][0];
    return {
      'risk_level': prediction > 0.7 ? 'High' : 'Low',
      'prediction_score': prediction,
      'suggestions': _getSuggestions(prediction)
    };
  }

  List<String> _getSuggestions(double prediction) {
    if (prediction > 0.7) {
      return [
        'অস্বাভাবিক কার্যকলাপ শনাক্ত হয়েছে!',
        'সন্তানের সাথে যোগাযোগ করুন',
        'অ্যাপ ব্যবহার সীমিত করুন'
      ];
    }
    return ['সবকিছু স্বাভাবিক অবস্থায় আছে'];
  }
}