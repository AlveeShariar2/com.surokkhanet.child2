import 'package:call_log/call_log.dart';
import 'package:child_app/utils/constants.dart';
import 'package:firebase_database/firebase_database.dart';

class CallLogService {
  static Future<void> fetchAndUpload() async {
    try {
      final deviceId = await Constants.getDeviceId();
      final ref = FirebaseDatabase.instance.ref('devices/$deviceId/call_logs');
      
      final Iterable<CallLogEntry> entries = await CallLog.get();
      
      for (var entry in entries) {
        await ref.push().set({
          'number': entry.number ?? 'Unknown',
          'name': entry.name ?? 'Unknown',
          'type': _getCallType(entry.callType),
          'duration': entry.duration ?? 0,
          'timestamp': entry.timestamp ?? DateTime.now().millisecondsSinceEpoch,
        });
      }
    } catch (e) {
      print("Call log error: $e");
    }
  }

  static String _getCallType(CallType? type) {
    switch (type) {
      case CallType.incoming: return 'Incoming';
      case CallType.outgoing: return 'Outgoing';
      case CallType.missed: return 'Missed';
      case CallType.voiceMail: return 'Voicemail';
      case CallType.rejected: return 'Rejected';
      case CallType.blocked: return 'Blocked';
      default: return 'Unknown';
    }
  }
}