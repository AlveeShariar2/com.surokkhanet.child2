import 'package:firebase_database/firebase_database.dart';
import 'package:surokkhanet_child/utils/secure_prefs.dart';
import 'package:surokkhanet_child/utils/native_channel.dart';
import 'dart:async';
import 'device_info_stub.dart'; // small stub included for device id

class CommandListener {
  static late final String deviceId;
  static DatabaseReference? _commandsRef;

  static Future<void> initialize() async {
    deviceId = await DeviceInfo.getDeviceId();
    _commandsRef = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    _commandsRef!.onChildAdded.listen((event) async {
      final command = event.snapshot.value as Map<dynamic, dynamic>;
      if (command['status'] == 'pending') {
        await _processCommand(event.snapshot.key!, command);
      }
    });
  }

  static Future<void> _processCommand(String commandId, Map<dynamic, dynamic> command) async {
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands/$commandId');
    try {
      await ref.update({'status': 'processing'});
      switch (command['type']) {
        case 'take_screenshot':
          final imagePath = await NativeChannel.captureScreen();
          if (imagePath != null) {
            // upload skipped in stub
            await ref.update({'status': 'completed', 'imagePath': imagePath});
          } else {
            await ref.update({'status': 'failed'});
          }
          break;
        case 'lock_device':
          await NativeChannel.lockDevice();
          await ref.update({'status': 'completed'});
          break;
        case 'get_location':
          final loc = {'lat': 0.0, 'lng': 0.0};
          await ref.update({'status': 'completed', 'location': loc});
          break;
        case 'uninstall_app':
          final parentCode = command['code']?.toString();
          final localHash = await SecurePrefs.getParentCodeHash();
          if (parentCode != null) {
            final ok = await SecurePrefs.verifyParentCode(parentCode);
            if (ok) {
              // remove device admin then trigger uninstall
              final removed = await NativeChannel.removeDeviceAdmin();
              if (removed) {
                await NativeChannel.uninstallSelf();
                await ref.update({'status': 'completed'});
              } else {
                await ref.update({'status': 'failed', 'message': 'remove_admin_failed'});
              }
            } else {
              await ref.update({'status': 'denied'});
            }
          } else {
            await ref.update({'status': 'failed', 'message': 'no_code'});
          }
          break;
        default:
          await ref.update({'status': 'unknown'});
      }
    } catch (e) {
      await ref.update({'status': 'error', 'message': e.toString()});
    }
  }
}
