import 'package:flutter/material.dart';
import 'package:flutter_sms/flutter_sms.dart';

class EmergencySOS extends StatefulWidget {
  @override
  _EmergencySOSState createState() => _EmergencySOSState();
}

class _EmergencySOSState extends State<EmergencySOS> {
  final List<String> _contacts = ["+8801XXXXXXXXX", "+8801XXXXXXXXX"];
  final String _message = "আমি বিপদে আছি! আমার বর্তমান অবস্থান: ";

  void _sendSOS() async {
    final location = await _getCurrentLocation();
    final fullMessage = _message + location.toString();
    
    await sendSMS(
      message: fullMessage,
      recipients: _contacts,
      sendDirect: true
    );
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('SOS বার্তা পাঠানো হয়েছে!'))
    );
  }

  Future<Map<String, double>> _getCurrentLocation() async {
    // লোকেশন সার্ভিস থেকে বর্তমান অবস্থান নিয়ে আসা
    return {'lat': 23.8103, 'lng': 90.4125};
  }

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton(
      backgroundColor: Colors.red,
      child: Icon(Icons.emergency),
      onPressed: _sendSOS,
    );
  }
}