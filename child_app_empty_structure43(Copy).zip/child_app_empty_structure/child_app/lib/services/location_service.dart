import 'package:geolocator/geolocator.dart';
import 'package:child_app/utils/constants.dart';
import 'package:firebase_database/firebase_database.dart';

class LocationService {
  static void start() {
    // Start location tracking
    Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 100, // meters
      )
    ).listen((Position position) async {
      final deviceId = await Constants.getDeviceId();
      final ref = FirebaseDatabase.instance.ref('devices/$deviceId/location');
      
      ref.set({
        'lat': position.latitude,
        'lng': position.longitude,
        'timestamp': ServerValue.timestamp,
      });
    });
  }
}