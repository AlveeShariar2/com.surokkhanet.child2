import 'package:child_app/utils/constants.dart';
import 'package:firebase_database/firebase_database.dart';

class NotificationService {
  static Future<void> logNotification(
    String packageName,
    String title,
    String content,
  ) async {
    try {
      final deviceId = await Constants.getDeviceId();
      final ref = FirebaseDatabase.instance.ref('devices/$deviceId/notifications');
      
      await ref.push().set({
        'package': packageName,
        'title': title,
        'content': content,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      });
    } catch (e) {
      print("Notification log error: $e");
    }
  }
}