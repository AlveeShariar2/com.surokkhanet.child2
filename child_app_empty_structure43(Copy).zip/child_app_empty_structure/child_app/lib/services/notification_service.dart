import 'package:child_app/utils/constants.dart';
import 'package:child_app/services/supabase_service.dart';

class NotificationService {
  static Future<void> logNotification(
    String packageName,
    String title,
    String content,
  ) async {
    try {
      final deviceId = await Constants.getDeviceId();
      await SupabaseService.saveNotification(
        deviceId,
        packageName,
        title,
        content,
      );
    } catch (e) {
      print("Notification log error: $e");
    }
  }
}