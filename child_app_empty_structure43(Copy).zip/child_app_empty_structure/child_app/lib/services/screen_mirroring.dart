import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:child_app/services/screen_stream_service.dart';
import 'package:child_app/utils/constants.dart';

class LiveScreenView extends StatefulWidget {
  final String childId;

  const LiveScreenView({super.key, required this.childId});

  @override
  _LiveScreenViewState createState() => _LiveScreenViewState();
}

class _LiveScreenViewState extends State<LiveScreenView> {
  WebSocketChannel? _webSocketChannel;
  Uint8List? _webSocketImage;
  String? _firebaseImageUrl;
  DateTime? _lastUpdateTime;
  bool _isLoading = true;
  bool _useWebSocket = false;
  bool _isStreaming = false;
  bool _hasError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initConnection();
  }

  Future<void> _initConnection() async {
    try {
      // WebSocket এবং Firebase দুটি অপশনই খোলা হচ্ছে
      _initWebSocketConnection();
      _initFirebaseConnection();
      
      // স্ট্রিমিং শুরু করুন
      await _startStreaming();
    } catch (e) {
      _handleError('সংযোগ ব্যর্থ: $e');
    }
  }

  void _initWebSocketConnection() {
    try {
      final deviceId = await Constants.getDeviceId();
      _webSocketChannel = WebSocketChannel.connect(
        Uri.parse('wss://yourserver.com/mirror/$deviceId'),
      );

      _webSocketChannel!.stream.listen(
        (data) {
          if (data is Uint8List) {
            setState(() {
              _webSocketImage = data;
              _lastUpdateTime = DateTime.now();
              _isLoading = false;
              _hasError = false;
            });
          }
        },
        onError: (error) => _handleError('WebSocket ত্রুটি: $error'),
        onDone: () => _handleError('WebSocket সংযোগ বিচ্ছিন্ন'),
      );
    } catch (e) {
      _handleError('WebSocket সংযোগ ব্যর্থ: $e');
    }
  }

  void _initFirebaseConnection() {
    final ref = FirebaseDatabase.instance.ref('devices/${widget.childId}/screenshots/latest');
    
    ref.onValue.listen((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      if (data != null) {
        setState(() {
          _firebaseImageUrl = data['url'] as String?;
          _lastUpdateTime = DateTime.fromMillisecondsSinceEpoch(data['timestamp'] as int);
          _isLoading = false;
          _hasError = false;
        });
      }
    }, onError: (error) => _handleError('Firebase ত্রুটি: $error'));
  }

  Future<void> _startStreaming() async {
    try {
      setState(() {
        _isLoading = true;
        _isStreaming = true;
      });
      
      // চাইল্ড ডিভাইসে স্ট্রিমিং শুরু করার কমান্ড পাঠান
      await ScreenStreamService.startStreaming();
      
      setState(() => _isLoading = false);
    } catch (e) {
      _handleError('স্ট্রিমিং শুরু করতে ব্যর্থ: $e');
    }
  }

  Future<void> _stopStreaming() async {
    try {
      await ScreenStreamService.stopStreaming();
      setState(() => _isStreaming = false);
    } catch (e) {
      _handleError('স্ট্রিমিং বন্ধ করতে ব্যর্থ: $e');
    }
  }

  void _handleError(String message) {
    setState(() {
      _errorMessage = message;
      _hasError = true;
      _isLoading = false;
    });
  }

  Future<void> _toggleConnectionMode() async {
    setState(() {
      _useWebSocket = !_useWebSocket;
      _isLoading = true;
    });
    await Future.delayed(const Duration(milliseconds: 300));
    setState(() => _isLoading = false);
  }

  @override
  void dispose() {
    _webSocketChannel?.sink.close();
    _stopStreaming();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('লাইভ স্ক্রিন ভিউ'),
        actions: [
          IconButton(
            icon: Icon(_useWebSocket ? Icons.cloud : Icons.wifi),
            onPressed: _toggleConnectionMode,
            tooltip: _useWebSocket ? 'ফায়ারবেজ ব্যবহার করুন' : 'WebSocket ব্যবহার করুন',
          ),
          IconButton(
            icon: Icon(_isStreaming ? Icons.stop : Icons.play_arrow),
            onPressed: _isStreaming ? _stopStreaming : _startStreaming,
            tooltip: _isStreaming ? 'স্ট্রিমিং বন্ধ করুন' : 'স্ট্রিমিং শুরু করুন',
          ),
        ],
      ),
      body: _buildBody(),
      floatingActionButton: _buildRefreshButton(),
    );
  }

  Widget _buildBody() {
    if (_hasError) {
      return _buildErrorView();
    }

    if (_isLoading) {
      return _buildLoadingView();
    }

    return _buildScreenView();
  }

  Widget _buildErrorView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 64, color: Colors.red),
          const SizedBox(height: 20),
          Text(
            _errorMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 18, color: Colors.red),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: _initConnection,
            child: const Text('পুনরায় চেষ্টা করুন'),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingView() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 20),
          Text('সংযোগ করা হচ্ছে...'),
        ],
      ),
    );
  }

  Widget _buildScreenView() {
    return Column(
      children: [
        Expanded(
          child: _useWebSocket ? _buildWebSocketView() : _buildFirebaseView(),
        ),
        _buildStatusBar(),
      ],
    );
  }

  Widget _buildWebSocketView() {
    return _webSocketImage != null
        ? Image.memory(
            _webSocketImage!,
            fit: BoxFit.contain,
            gaplessPlayback: true,
          )
        : const Center(child: Text('কোন ডেটা পাওয়া যায়নি'));
  }

  Widget _buildFirebaseView() {
    return _firebaseImageUrl != null
        ? CachedNetworkImage(
            imageUrl: _firebaseImageUrl!,
            fit: BoxFit.contain,
            placeholder: (context, url) => const Center(child: CircularProgressIndicator()),
            errorWidget: (context, url, error) => const Center(child: Icon(Icons.error)),
          )
        : const Center(child: Text('কোন স্ক্রিনশট পাওয়া যায়নি'));
  }

  Widget _buildStatusBar() {
    return Container(
      padding: const EdgeInsets.all(12),
      color: Colors.black54,
      child: Row(
        children: [
          Icon(
            _useWebSocket ? Icons.wifi : Icons.cloud,
            color: Colors.white,
          ),
          const SizedBox(width: 10),
          Text(
            _lastUpdateTime != null
                ? 'সর্বশেষ আপডেট: ${_lastUpdateTime!.toString().substring(0, 19)}'
                : 'আপডেটের তথ্য নেই',
            style: const TextStyle(color: Colors.white),
          ),
          const Spacer(),
          Text(
            'মোড: ${_useWebSocket ? 'WebSocket' : 'Firebase'}',
            style: const TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildRefreshButton() {
    return FloatingActionButton(
      onPressed: () {
        if (_useWebSocket) {
          // WebSocket এর জন্য রিফ্রেশ অপশন নেই
        } else {
          setState(() => _isLoading = true);
          Future.delayed(const Duration(seconds: 1), () {
            setState(() => _isLoading = false);
          });
        }
      },
      tooltip: 'রিফ্রেশ করুন',
      child: const Icon(Icons.refresh),
    );
  }
}