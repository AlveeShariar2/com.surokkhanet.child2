import 'dart:async';
import 'dart:typed_data';
import 'package:child_app/utils/native_channel.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:firebase_database/firebase_database.dart';

class ScreenStreamService {
  // Firebase instances
  static final FirebaseStorage _storage = FirebaseStorage.instance;
  static final DatabaseReference _dbRef = 
      FirebaseDatabase.instance.ref('live_screens');

  // Streaming state
  static bool _isStreaming = false;
  static String? _currentChildId;
  static Timer? _captureTimer;

  // Native channel helper
  static final NativeChannel _nativeChannel = NativeChannel();

  // Start screen streaming
  static Future<bool> startStreaming(String childId, {int intervalSeconds = 5}) async {
    try {
      if (_isStreaming) await stopStreaming();
      
      // Start native screen capture
      await _nativeChannel.startScreenStream();
      debugPrint('Native screen streaming started');
      
      // Set child ID and interval
      _currentChildId = childId;
      await setCaptureInterval(intervalSeconds);
      
      _isStreaming = true;
      return true;
    } on PlatformException catch (e) {
      debugPrint("Failed to start stream: ${e.message}");
      return false;
    } catch (e) {
      debugPrint("Unexpected error: $e");
      return false;
    }
  }

  // Stop screen streaming
  static Future<bool> stopStreaming() async {
    try {
      await _nativeChannel.stopScreenStream();
      _captureTimer?.cancel();
      _captureTimer = null;
      
      _isStreaming = false;
      debugPrint('Screen streaming stopped');
      return true;
    } on PlatformException catch (e) {
      debugPrint("Failed to stop stream: ${e.message}");
      return false;
    } catch (e) {
      debugPrint("Unexpected error: $e");
      return false;
    }
  }

  // Set capture interval
  static Future<void> setCaptureInterval(int seconds) async {
    try {
      await _nativeChannel.setScreenCaptureInterval(seconds);
      
      // Setup periodic capture
      _captureTimer?.cancel();
      _captureTimer = Timer.periodic(
        Duration(seconds: seconds),
        (_) => _captureAndUploadFrame(),
      );
      
      debugPrint('Capture interval set to $seconds seconds');
    } on PlatformException catch (e) {
      debugPrint("Failed to set interval: ${e.message}");
    }
  }

  // Capture and upload frame
  static Future<void> _captureAndUploadFrame() async {
    if (!_isStreaming || _currentChildId == null) return;

    try {
      // 1. Capture frame from native
      final Uint8List? frame = await _nativeChannel.captureScreenFrame();
      if (frame == null || frame.isEmpty) return;

      // 2. Upload to Firebase Storage
      final String fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
      final Reference ref = _storage.ref('live_screens/$_currentChildId/$fileName');
      await ref.putData(frame, SettableMetadata(contentType: 'image/jpeg'));

      // 3. Get download URL
      final String url = await ref.getDownloadURL();

      // 4. Update Realtime Database
      await _dbRef.child(_currentChildId!).set({
        'last_frame': url,
        'timestamp': ServerValue.timestamp,
      });

      debugPrint('Frame uploaded successfully');
    } catch (e) {
      debugPrint('Frame upload error: $e');
    }
  }

  // Get live screen stream
  static Stream<String> getScreenStream(String childId) {
    return _dbRef.child(childId).onValue.asyncMap((event) {
      final data = event.snapshot.value as Map<dynamic, dynamic>?;
      return data?['last_frame']?.toString() ?? '';
    });
  }

  // Check if streaming is active
  static Future<bool> isStreamingActive() async {
    try {
      final isActive = await _nativeChannel.isScreenStreamActive();
      return isActive && _isStreaming;
    } on PlatformException {
      return false;
    }
  }
}