import 'package:child_app/utils/constants.dart';
import 'package:child_app/services/supabase_service.dart';

class SmsMonitor {
  static Future<void> fetchSms() async {
    // Android-এ এসএমএস এক্সেসের জন্য নেটিভ কোড প্রয়োজন
    // এই ফাংশনটি নেটিভ চ্যানেলের মাধ্যমে ইমপ্লিমেন্ট করা হবে
  }
}