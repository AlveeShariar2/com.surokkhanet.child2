import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:child_app/utils/supabase_config.dart';

class SupabaseService {
  static final SupabaseClient client = Supabase.instance.client;

  static Future<void> initialize() async {
    await Supabase.initialize(
      url: SupabaseConfig.supabaseUrl,
      anonKey: SupabaseConfig.supabaseAnonKey,
    );
  }

  // ডিভাইস রেজিস্ট্রেশন
  static Future<void> registerDevice(String deviceId, String deviceName) async {
    await client
        .from('devices')
        .upsert({
          'device_id': deviceId,
          'device_name': deviceName,
          'created_at': DateTime.now().toIso8601String(),
        });
  }

  // কমান্ড সেন্ড করা
  static Future<void> sendCommand(String deviceId, String type, 
                                {Map<String, dynamic>? data}) async {
    await client.from('commands').insert({
      'device_id': deviceId,
      'type': type,
      'status': 'pending',
      'data': data,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // কমান্ড স্ট্যাটাস আপডেট
  static Future<void> updateCommandStatus(String commandId, String status,
                                        {String? error}) async {
    await client
        .from('commands')
        .update({
          'status': status,
          'error': error,
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', commandId);
  }

  // লোকেশন সেভ করা
  static Future<void> saveLocation(String deviceId, double lat, double lng,
                                  double accuracy) async {
    await client.from('locations').insert({
      'device_id': deviceId,
      'lat': lat,
      'lng': lng,
      'accuracy': accuracy,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // নোটিফিকেশন সেভ করা
  static Future<void> saveNotification(String deviceId, String packageName,
                                      String title, String content) async {
    await client.from('notifications').insert({
      'device_id': deviceId,
      'package_name': packageName,
      'title': title,
      'content': content,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // কল লগ সেভ করা
  static Future<void> saveCallLog(String deviceId, String number, String name,
                                 String type, int duration, int timestamp) async {
    await client.from('call_logs').insert({
      'device_id': deviceId,
      'number': number,
      'name': name,
      'type': type,
      'duration': duration,
      'timestamp': timestamp,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  // রিয়েলটাইম কমান্ড লিসেনার
  static RealtimeSubscription listenToCommands(String deviceId, 
                                              Function(Map<String, dynamic>) callback) {
    final subscription = client
        .from('commands')
        .on(SupabaseEventTypes.all, (payload) {
          final newRecord = payload.newRecord;
          if (newRecord['device_id'] == deviceId && 
              newRecord['status'] == 'pending') {
            callback(newRecord);
          }
        })
        .subscribe();

    return subscription;
  }
}