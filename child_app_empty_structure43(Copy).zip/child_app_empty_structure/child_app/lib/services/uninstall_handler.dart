import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';
import 'package:child_app/utils/native_channel.dart';

class UninstallHandler {
  static Future<void> init() async {
    final deviceId = await Constants.getDeviceId();
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId/commands');
    
    ref.orderByChild('type').equalTo('uninstall_app').onChildAdded.listen((event) {
      NativeChannel.triggerUninstall();
    });
  }
}