import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:child_app/utils/constants.dart';

class LinkScreen extends StatefulWidget {
  const LinkScreen({super.key});

  @override
  State<LinkScreen> createState() => _LinkScreenState();
}

class _LinkScreenState extends State<LinkScreen> {
  final _codeController = TextEditingController();
  String _status = '';

  Future<void> _linkDevice() async {
    if (_codeController.text.isEmpty) {
      setState(() => _status = 'Please enter code');
      return;
    }

    final deviceId = await Constants.getDeviceId();
    final ref = FirebaseDatabase.instance.ref('devices/$deviceId');
    
    try {
      await ref.update({
        'parent_code': _codeController.text,
        'linked': true,
      });
      setState(() => _status = 'Device linked successfully!');
    } catch (e) {
      setState(() => _status = 'Linking failed: ${e.toString()}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Link Device')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _codeController,
              decoration: const InputDecoration(
                labelText: 'Enter Parent Code',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _linkDevice,
              child: const Text('Link Device'),
            ),
            const SizedBox(height: 20),
            Text(_status),
          ],
        ),
      ),
    );
  }
}