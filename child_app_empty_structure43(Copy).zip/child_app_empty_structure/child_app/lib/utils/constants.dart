import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';

class Constants {
  static Future<String> getDeviceId() async {
    final deviceInfo = DeviceInfoPlugin();
    
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      return androidInfo.androidId; // Use Android ID
    }
    
    return 'unknown_device_${DateTime.now().millisecondsSinceEpoch}';
  }
}