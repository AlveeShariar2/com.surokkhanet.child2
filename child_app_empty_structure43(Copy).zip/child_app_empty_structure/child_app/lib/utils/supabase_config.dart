class SupabaseConfig {
  static const String supabaseUrl = 'https://tkhxgcnxxchybtkwuwzb.supabase.co';
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRraHhnY254eGNoeWJ0a3d1d3piIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU5MDgzNjUsImV4cCI6MjA3MTQ4NDM2NX0.72_nIEGYPpm4blZmCX787ZTwGmT7yXZGAxUqPLLnoK4';
  
  static const Map<String, String> headers = {
    'Content-Type': 'application/json',
    'apikey': supabaseAnonKey,
  };
}